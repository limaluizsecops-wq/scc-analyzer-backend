function example() {
  console.log("This is an example function.");
}
